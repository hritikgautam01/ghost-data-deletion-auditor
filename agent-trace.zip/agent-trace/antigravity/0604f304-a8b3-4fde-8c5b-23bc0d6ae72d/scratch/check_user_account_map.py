import json, glob
import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

user_to_account = {}

# Check all snapshots in evidence/records
for fpath in glob.glob(str(dataset_dir / "evidence/records/customer_data_snapshot_bundle_*.json")):
    try:
        with open(fpath, "r", encoding="utf-8") as f:
            bundle_data = json.load(f)
            for snap in bundle_data.get("snapshots", []):
                if snap.get("data_store") == "account_service":
                    for rec in snap.get("records", []):
                        uid = rec.get("customer_reference") or rec.get("user_id")
                        acc = rec.get("resource_id") or rec.get("account_id")
                        if uid and acc:
                            user_to_account[uid] = acc
    except Exception:
        pass

# Also check SQLite databases
import sqlite3
for fpath in glob.glob(str(dataset_dir / "evidence/databases/*.sql")):
    try:
        conn = sqlite3.connect(":memory:")
        with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
            sql = f.read()
        conn.executescript(sql)
        cursor = conn.cursor()
        for t in ["customer_profiles", "customer_profiles_failover_replica"]:
            try:
                for row in cursor.execute(f"SELECT user_id, account_id FROM {t}"):
                    if row[0] and row[1]:
                        user_to_account[row[0]] = row[1]
            except Exception:
                pass
        conn.close()
    except Exception:
        pass

print(f"Total user_id -> account_id mappings discovered: {len(user_to_account)}")

# Check sample users
sample_reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
users_df = pd.read_csv(dataset_dir / "user_identities.csv")
email_to_uid = dict(zip(users_df["email"], users_df["user_id"]))

sample_out = pd.read_csv(dataset_dir / "sample_output.csv")
gt_accounts = {}
for _, r in sample_out.iterrows():
    steps = json.loads(r["steps_json"])
    for s in steps:
        if s["system_id"] == "account_service":
            gt_accounts[r["case_id"]] = s["resource_id"]
            break

matches = 0
for _, r in sample_reqs.iterrows():
    cid = r["case_id"]
    email = r["email"]
    uid = email_to_uid.get(email)
    acc = user_to_account.get(uid)
    gt_acc = gt_accounts.get(cid)
    is_m = (acc == gt_acc)
    if is_m:
        matches += 1
    print(f"{cid} (uid={uid}): mapped={acc}, gt={gt_acc} {'[MATCH]' if is_m else '[DIFF]'}")

print(f"\nAccount mapping accuracy on sample cases: {matches} / {len(sample_reqs)}")
