import json
import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

sample_out = pd.read_csv(dataset_dir / "sample_output.csv")
sample_reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
act = pd.read_csv(dataset_dir / "system_activity.csv")
act["dt"] = pd.to_datetime(act["event_time"])

for _, req in sample_reqs.iterrows():
    cid = req["case_id"]
    email = req["email"]
    rep_at = pd.to_datetime(req["reported_at"])
    
    # Ground truth steps for this case
    gt_row = sample_out[sample_out["case_id"] == cid].iloc[0]
    gt_steps = json.loads(gt_row["steps_json"])
    gt_resources = list(dict.fromkeys(s["resource_id"] for s in gt_steps))
    
    # Look at activities between rep_at - 2h and rep_at + 2h
    window_acts = act[(act["dt"] >= rep_at - pd.Timedelta(hours=2)) & (act["dt"] <= rep_at + pd.Timedelta(hours=2))]
    del_acts = window_acts[window_acts["source_system"] == "deletion_worker"]
    del_res = list(dict.fromkeys(del_acts["resource_id"]))
    
    # How many gt_resources are in del_res?
    overlap = set(gt_resources).intersection(del_res)
    print(f"{cid} ({email}) rep_at={rep_at}:")
    print(f"  GT Resources: {gt_resources}")
    print(f"  Del Worker Res in Window: {del_res}")
    print(f"  Overlap: {overlap}")
