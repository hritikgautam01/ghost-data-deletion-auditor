import sys, json
import pandas as pd
sys.path.insert(0, '.')
from code.src.data.loader import load_dataset_bundle
from code.src.evidence.manifest import EvidenceManifest
from code.src.evidence.json_extractor import extract_eligible_json, extract_all_records
from code.src.evidence.log_parser import extract_eligible_logs_and_text, extract_all_log_records
from code.src.evidence.sql_engine import extract_eligible_sql, extract_all_sql_records

outs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_output.csv')
users = pd.read_csv('hackerrank-orchestrate-october26/dataset/user_identities.csv')
audits = pd.read_csv('hackerrank-orchestrate-october26/dataset/user_audit_log.csv')
reqs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_deletion_requests.csv')

email_to_user = {row['email'].strip().lower(): row['user_id'] for _, row in users.iterrows()}
for _, row in audits[audits['field_name']=='email'].iterrows():
    if pd.notna(row['old_value']):
        email_to_user[row['old_value'].strip().lower()] = row['user_id']
    if pd.notna(row['new_value']):
        email_to_user[row['new_value'].strip().lower()] = row['user_id']

manifest = EvidenceManifest()
for _, r in outs.iterrows():
    cid = r['case_id']
    steps = json.loads(r['steps_json'])
    gold_audit_recs = [s['resource_id'] for s in steps if s['system_id'] == 'security_service']
    if gold_audit_recs:
        req = reqs[reqs['case_id'] == cid].iloc[0]
        uid = email_to_user.get(req['email'].strip().lower())
        print(f"{cid} ({uid}): gold security audit recs = {gold_audit_recs}")
