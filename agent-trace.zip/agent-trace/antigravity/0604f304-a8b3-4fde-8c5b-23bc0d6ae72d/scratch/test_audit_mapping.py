import sys, json
sys.path.insert(0, '.')
from code.src.data.loader import find_dataset_dir, load_dataset_bundle
from code.src.identity.resolver import IdentityResolver

base_dir = find_dataset_dir()
user_to_audit = {}
for e_path in (
    'evidence/records/customer_data_snapshot_bundle_20260725.json',
    'evidence/records/customer_data_snapshot_bundle_20260915.json',
    'evidence/records/customer_data_snapshot_bundle_20260917.json',
    'evidence/records/service_resource_export_20260915_114455.json',
):
    p = base_dir / e_path
    if p.exists():
        with open(p) as fp:
            d = json.load(fp)
            if 'snapshots' in d:
                for s in d['snapshots']:
                    if s.get('data_store') == 'security_service':
                        for r in s.get('records', []):
                            u = r.get('subject_reference')
                            rid = r.get('resource_id')
                            if u and rid:
                                user_to_audit[u] = rid
            if 'service_exports' in d:
                sec = d['service_exports'].get('security_service', {})
                for r in sec.get('audit_records', []):
                    u = r.get('subject_reference')
                    rid = r.get('resource_id')
                    if u and rid:
                        user_to_audit[u] = rid

b = load_dataset_bundle()
res = IdentityResolver(b.user_identities, b.user_audit_log)
sample_truth = {r.case_id: r for r in b.sample_output}

for c in b.sample_deletion_requests:
    subj = res.resolve(c)
    t = sample_truth.get(c.case_id)
    t_steps = json.loads(t.steps_json)
    sec_steps = [s for s in t_steps if s['system_id'] == 'security_service']
    if sec_steps:
        mapped = user_to_audit.get(subj.primary_user_id)
        truth_rid = sec_steps[0]['resource_id']
        match = (mapped == truth_rid)
        print(f"{c.case_id}: truth={truth_rid}, mapped={mapped}, match={match}")
