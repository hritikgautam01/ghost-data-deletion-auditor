import sys
sys.path.insert(0, '.')
from code.src.data.loader import load_dataset_bundle
from code.src.evidence.manifest import EvidenceManifest
from code.src.evidence.json_extractor import extract_eligible_json, extract_all_records
from code.src.evidence.log_parser import extract_eligible_logs_and_text, extract_all_log_records
from code.src.evidence.sql_engine import extract_eligible_sql, extract_all_sql_records
from code.src.evidence.doc_extractor import extract_eligible_docs_and_images, extract_all_doc_records

bundle = load_dataset_bundle()
manifest = EvidenceManifest()

# Let's inspect case_15 (lucia-torres@gmail.com, audit_at = 2026-09-15T12:00:00Z)
case_15 = [c for c in bundle.deletion_requests if c.case_id == 'case_15']
if not case_15:
    case_15 = [c for c in bundle.sample_deletion_requests if c.case_id == 'case_15']
c15 = case_15[0]
print(f"Case 15: {c15.email}, audit_at: {c15.audit_at}")

# Extract eligible logs at audit_at
logs = extract_all_log_records(extract_eligible_logs_and_text(manifest, audit_at=c15.audit_at))
print(f"Total eligible log records at {c15.audit_at}: {len(logs)}")
matches = [r for r in logs if any(v == 'lucia-torres@gmail.com' or v == 'user_15' for v in r.identifiers.values())]
print(f"Log matches for case_15: {len(matches)}")
for m in matches:
    print("  Log:", m.evidence_id, m.source_system, m.resource_id, m.identifiers, m.raw_payload.get('event'), m.raw_payload.get('http_status'))

# Also check JSON records
jsons = extract_all_records(extract_eligible_json(manifest, audit_at=c15.audit_at))
j_matches = [r for r in jsons if any(v == 'lucia-torres@gmail.com' or v == 'user_15' for v in r.identifiers.values())]
print(f"JSON matches for case_15: {len(j_matches)}")
for m in j_matches:
    print("  JSON:", m.evidence_id, m.source_system, m.resource_id, m.identifiers)
