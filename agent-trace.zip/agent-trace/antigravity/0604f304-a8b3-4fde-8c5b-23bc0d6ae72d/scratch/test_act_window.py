import pandas as pd
import json

reqs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_deletion_requests.csv')
outs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_output.csv')
acts = pd.read_csv('hackerrank-orchestrate-october26/dataset/system_activity.csv')

acts['dt'] = pd.to_datetime(acts['event_time'])
reqs['rep_dt'] = pd.to_datetime(reqs['reported_at'])

for idx, r in reqs.head(5).iterrows():
    cid = r['case_id']
    # Window of +/- 2 hours around reported_at
    sub = acts[(acts['dt'] >= r['rep_dt'] - pd.Timedelta(hours=2)) & (acts['dt'] <= r['rep_dt'] + pd.Timedelta(hours=2))]
    print(f"=== {cid} reported_at={r['reported_at']} reported_status={r['reported_status']} ===")
    for _, a in sub.iterrows():
        print(f"   {a['activity_id']} | {a['event_time']} | {a['event_type']} | {a['source_system']} -> {a['target_system']} | res={a['resource_id']} | result={a['reported_result']} | details={a['details']}")
