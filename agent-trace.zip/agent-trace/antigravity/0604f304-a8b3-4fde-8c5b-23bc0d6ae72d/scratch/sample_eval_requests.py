import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

reqs = pd.read_csv(dataset_dir / "deletion_requests.csv")
print("Total eval requests:", len(reqs))

# Sample 15 request texts
for txt in reqs["request_text"].sample(15, random_state=42):
    print(" -", txt)
