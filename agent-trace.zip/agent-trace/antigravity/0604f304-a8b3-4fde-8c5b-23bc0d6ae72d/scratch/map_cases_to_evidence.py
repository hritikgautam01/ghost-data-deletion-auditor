import json
import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

sample_out = pd.read_csv(dataset_dir / "sample_output.csv")
sample_reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
users_df = pd.read_csv(dataset_dir / "user_identities.csv")
user_map = {r["email"]: r["user_id"] for _, r in users_df.iterrows()}

# For each case, print:
# 1. Subject info (user_id, email, phone, name)
# 2. Evidence IDs cited in ground truth
for _, row in sample_out.iterrows():
    cid = row["case_id"]
    steps = json.loads(row["steps_json"])
    req = sample_reqs[sample_reqs["case_id"] == cid].iloc[0]
    email = req["email"]
    uid = user_map.get(email)
    
    ev_ids = sorted(list(set(s["evidence_id"] for s in steps if s["evidence_id"])))
    res_ids = [f"{s['system_id']}:{s['resource_id']}({s['operation']})" for s in steps if s["phase"] in ["FINDING", "VERIFICATION"]]
    
    print(f"\n{cid} ({uid}, {email}) Status: {row['deletion_status']} Ev: {ev_ids}")
    print(f"  Resources: {res_ids}")
