import json
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

fpath = dataset_dir / "evidence/records/customer_data_snapshot_bundle_20260917.json"
with open(fpath, "r", encoding="utf-8") as f:
    data = json.load(f)

for snap in data.get("snapshots", []):
    for rec in snap.get("records", []):
        text = json.dumps(rec)
        if "5684" in text or "4566" in text or "user_26" in text or "mariana" in text:
            print(f"Store: {snap.get('data_store')}, Coll: {snap.get('collection')}: {rec}")
