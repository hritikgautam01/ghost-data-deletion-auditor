import json
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

fpath = dataset_dir / "evidence/records/service_resource_export_20260915_114455.json"
with open(fpath, "r", encoding="utf-8") as f:
    data = json.load(f)

exports = data["service_exports"]

print("--- user_26 search in evidence_92 ---")
for sname, sdata in exports.items():
    for coll_name, items in sdata.items():
        if isinstance(items, list):
            for it in items:
                text = json.dumps(it)
                if "user_26" in text or "almeida" in text or "5684" in text:
                    print(f"Service: {sname}.{coll_name}: {it}")
