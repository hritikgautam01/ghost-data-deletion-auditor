import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

act = pd.read_csv(dataset_dir / "system_activity.csv")
requests_df = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")

act["dt"] = pd.to_datetime(act["event_time"])

for _, req in requests_df.iterrows():
    cid = req["case_id"]
    email = req["email"]
    rep_at = pd.to_datetime(req["reported_at"])
    
    sub_acts = act[(act["dt"] >= rep_at - pd.Timedelta(hours=2)) & 
                   (act["dt"] <= rep_at + pd.Timedelta(hours=2))]
    
    del_acts = sub_acts[sub_acts["source_system"] == "deletion_worker"]
    if len(del_acts) > 0:
        print(f"\n{cid} ({email}) rep_at={rep_at}:")
        for _, a in del_acts.iterrows():
            print(f"  {a['activity_id']} | {a['event_time']} | {a['event_type']} | {a['target_system']} | {a['resource_id']} | {a['reported_result']} | {a['details']}")
