import os
import sys
sys.path.insert(0, os.getcwd())
import json
from code.src.data.loader import load_dataset_bundle
from code.src.pipeline import AuditPipeline

bundle = load_dataset_bundle()
pipeline = AuditPipeline(dataset_bundle=bundle)
truth_map = {r.case_id: r for r in bundle.sample_output}

mismatches = 0
for c in bundle.sample_deletion_requests:
    res = pipeline.process_case(c)
    tr = truth_map.get(c.case_id)
    pred_steps = json.loads(res.steps_json)
    tr_steps = json.loads(tr.steps_json)
    
    st_match = res.deletion_status == tr.deletion_status
    seq_match = (pred_steps == tr_steps)
    if not seq_match or not st_match:
        mismatches += 1
        print(f"=== {c.case_id} === Status: {res.deletion_status} (Truth: {tr.deletion_status})")
        p_keys = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state']) for s in pred_steps]
        t_keys = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state']) for s in tr_steps]
        extra = [k for k in p_keys if k not in t_keys]
        missing = [k for k in t_keys if k not in p_keys]
        if extra:
            print("  Extra in pred:", extra)
        if missing:
            print("  Missing in pred:", missing)
        if p_keys == t_keys:
            for i, (ps, ts) in enumerate(zip(pred_steps, tr_steps)):
                if ps['evidence_id'] != ts['evidence_id']:
                    print(f"  Step {i+1} ev_id diff for {ps['resource_id']}: pred='{ps['evidence_id']}' truth='{ts['evidence_id']}'")

print(f"\nTotal mismatches: {mismatches}/32")
