import sqlite3
conn = sqlite3.connect(':memory:')
with open('hackerrank-orchestrate-october26/dataset/evidence/databases/customer_search_primary_20260910.sql') as f:
    conn.executescript(f.read())
cur = conn.cursor()
cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = cur.fetchall()
print('evidence_57 tables:', tables)
for t in tables:
    cur.execute(f"SELECT * FROM {t[0]}")
    rows = cur.fetchall()
    print(t[0], 'row count:', len(rows))
    for r in rows:
        print('  ', r)
