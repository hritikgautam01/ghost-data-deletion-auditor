import json, os, glob
import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

sample_out = pd.read_csv(dataset_dir / "sample_output.csv")
sample_reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
users_df = pd.read_csv(dataset_dir / "user_identities.csv")
user_map = {r["email"]: r["user_id"] for _, r in users_df.iterrows()}

all_rows = []
for _, row in sample_out.iterrows():
    cid = row["case_id"]
    steps = json.loads(row["steps_json"])
    req = sample_reqs[sample_reqs["case_id"] == cid].iloc[0]
    email = req["email"]
    uid = user_map.get(email)
    
    for s in steps:
        all_rows.append({
            "case_id": cid,
            "user_id": uid,
            "email": email,
            "system_id": s["system_id"],
            "resource_id": s["resource_id"],
            "operation": s["operation"],
            "phase": s["phase"],
            "evidence_id": s["evidence_id"]
        })

df = pd.DataFrame(all_rows)

# Check unique resources
unique_resources = df[["resource_id", "system_id", "user_id", "email", "case_id"]].drop_duplicates("resource_id")

# Let's inspect evidence files
evidence_manifest = pd.read_csv(dataset_dir / "evidence_files.csv")

# For each unique resource, find which evidence file contains it
res_found = {}
for fpath in glob.glob(str(dataset_dir / "evidence" / "**" / "*"), recursive=True):
    if os.path.isfile(fpath) and not fpath.endswith((".png", ".pdf", ".pyc")):
        rel_path = os.path.relpath(fpath, dataset_dir).replace("\\", "/")
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
                for _, r in unique_resources.iterrows():
                    rid = r["resource_id"]
                    if rid in content:
                        res_found.setdefault(rid, []).append(rel_path)
        except Exception:
            pass

print(f"Total unique resources: {len(unique_resources)}")
print(f"Resources found in evidence files: {len(res_found)}")
not_found_in_ev = [r["resource_id"] for _, r in unique_resources.iterrows() if r["resource_id"] not in res_found]
print(f"Resources NOT found in evidence files: {len(not_found_in_ev)}")
if not_found_in_ev:
    print("Sample not found:", not_found_in_ev[:10])
