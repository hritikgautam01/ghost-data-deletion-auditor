import json
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

fpath = dataset_dir / "evidence/records/service_resource_export_20260915_114455.json"
with open(fpath, "r", encoding="utf-8") as f:
    data = json.load(f)

for rec in data["service_exports"]["security_service"]["audit_records"]:
    if rec["resource_id"] == "audit_record_451":
        print("audit_record_451:", rec)
