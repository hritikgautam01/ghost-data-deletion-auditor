import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

act = pd.read_csv(dataset_dir / "system_activity.csv")
print("Columns:", list(act.columns))
print("\nRows for account_4857:")
print(act[act["resource_id"] == "account_4857"].to_dict(orient="records"))
print("\nRows for account_8858:")
print(act[act["resource_id"] == "account_8858"].to_dict(orient="records"))
