import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

reqs = pd.read_csv(dataset_dir / "deletion_requests.csv")
tail = reqs[reqs["case_id"] >= "case_530"]
for _, r in tail.iterrows():
    print(f"\n{r['case_id']}: {r['request_text']}")
