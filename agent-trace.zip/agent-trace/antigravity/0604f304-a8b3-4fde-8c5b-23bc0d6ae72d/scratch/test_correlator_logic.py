import sys, json
import pandas as pd
from datetime import datetime, timezone
sys.path.insert(0, '.')

from code.src.data.loader import load_dataset_bundle
from code.src.evidence.manifest import EvidenceManifest
from code.src.evidence.json_extractor import extract_eligible_json, extract_all_records
from code.src.evidence.log_parser import extract_eligible_logs_and_text, extract_all_log_records
from code.src.evidence.sql_engine import extract_eligible_sql, extract_all_sql_records
from code.src.evidence.doc_extractor import extract_eligible_docs_and_images, extract_all_doc_records
from code.src.identity.resolver import IdentityResolver

bundle = load_dataset_bundle()
resolver = IdentityResolver(bundle.user_identities, bundle.user_audit_log)
manifest = EvidenceManifest()
outs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_output.csv')

print("Ready to test correlator logic.")
