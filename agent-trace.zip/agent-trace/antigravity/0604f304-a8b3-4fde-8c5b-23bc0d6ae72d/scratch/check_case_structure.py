import pandas as pd
import json

reqs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_deletion_requests.csv')
outs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_output.csv')
acts = pd.read_csv('hackerrank-orchestrate-october26/dataset/system_activity.csv')
users = pd.read_csv('hackerrank-orchestrate-october26/dataset/user_identities.csv')
audits = pd.read_csv('hackerrank-orchestrate-october26/dataset/user_audit_log.csv')

acts['dt'] = pd.to_datetime(acts['event_time'])

email_to_user = {row['email'].strip().lower(): row['user_id'] for _, row in users.iterrows()}
for _, row in audits[audits['field_name']=='email'].iterrows():
    if pd.notna(row['old_value']):
        email_to_user[row['old_value'].strip().lower()] = row['user_id']
    if pd.notna(row['new_value']):
        email_to_user[row['new_value'].strip().lower()] = row['user_id']

for idx, r in outs.iterrows():
    cid = r['case_id']
    status = r['deletion_status']
    steps = json.loads(r['steps_json'])
    req = reqs[reqs['case_id'] == cid].iloc[0]
    rep_dt = pd.to_datetime(req['reported_at'])
    
    findings = [s for s in steps if s['phase'] == 'FINDING']
    verifs = [s for s in steps if s['phase'] == 'VERIFICATION']
    
    # Check acts near reported_at
    nearby_acts = acts[(acts['dt'] >= rep_dt - pd.Timedelta(hours=4)) & (acts['dt'] <= rep_dt + pd.Timedelta(hours=4))]
    
    finding_summary = [(f['system_id'], f['resource_id'], f['operation'], f['evidence_id']) for f in findings]
    verif_res = [v['resource_id'] for v in verifs]
    
    print(f"Case {cid} ({status}):")
    print(f"  Findings: {finding_summary}")
    print(f"  Verif resources: {verif_res}")
    print(f"  Nearby activities: {len(nearby_acts)} acts")
