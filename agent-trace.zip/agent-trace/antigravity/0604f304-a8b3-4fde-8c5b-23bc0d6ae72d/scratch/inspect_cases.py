import sqlite3
import pandas as pd
import json

conn = sqlite3.connect(':memory:')
with open('hackerrank-orchestrate-october26/dataset/evidence/databases/customer_accounts_failover_replica_20260902.sql') as f:
    conn.executescript(f.read())
cur = conn.cursor()
cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = cur.fetchall()
print('Tables in evidence_54:', tables)
for t in tables:
    cur.execute(f"SELECT * FROM {t[0]}")
    rows = cur.fetchall()
    print(t[0], 'row count:', len(rows))
    for r in rows:
        print('  ', r)
