import pandas as pd
import json

reqs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_deletion_requests.csv')
outs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_output.csv')
users = pd.read_csv('hackerrank-orchestrate-october26/dataset/user_identities.csv')
audits = pd.read_csv('hackerrank-orchestrate-october26/dataset/user_audit_log.csv')

# Build user identity map
email_to_user = {row['email'].strip().lower(): row['user_id'] for _, row in users.iterrows()}
for _, row in audits[audits['field_name']=='email'].iterrows():
    if pd.notna(row['old_value']):
        email_to_user[row['old_value'].strip().lower()] = row['user_id']
    if pd.notna(row['new_value']):
        email_to_user[row['new_value'].strip().lower()] = row['user_id']

merged = pd.merge(reqs, outs, on='case_id')
for idx, r in merged.iterrows():
    cid = r['case_id']
    em = r['email'].strip().lower()
    uid = email_to_user.get(em, 'UNKNOWN')
    status = r['deletion_status']
    steps = json.loads(r['steps_json'])
    findings = [s for s in steps if s['phase'] == 'FINDING']
    remeds = [s for s in steps if s['phase'] == 'REMEDIATION']
    verifs = [s for s in steps if s['phase'] == 'VERIFICATION']
    
    print(f"\n--- {cid} | user: {uid} | email: {em} | status: {status} | reported: {r['reported_status']} ---")
    if findings:
        print("  FINDINGS:")
        for f in findings:
            print(f"    {f['system_id']} / {f['resource_id']} -> {f['operation']} ({f['state']}) ev={f['evidence_id']}")
    if remeds:
        print("  REMEDIATIONS:")
        for rem in remeds:
            print(f"    {rem['system_id']} / {rem['resource_id']} -> {rem['operation']} ({rem['state']})")
    print("  VERIFICATIONS:")
    for v in verifs:
        print(f"    {v['system_id']} / {v['resource_id']} -> {v['operation']} ({v['state']}) ev='{v['evidence_id']}'")
