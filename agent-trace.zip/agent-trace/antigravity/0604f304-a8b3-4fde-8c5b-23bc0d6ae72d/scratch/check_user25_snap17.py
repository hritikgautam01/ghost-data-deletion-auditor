import json
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

fpath = dataset_dir / "evidence/records/customer_data_snapshot_bundle_20260917.json"
with open(fpath, "r", encoding="utf-8") as f:
    data = json.load(f)

for snap in data.get("snapshots", []):
    for rec in snap.get("records", []):
        text = json.dumps(rec)
        if "3136" in text or "1895" in text or "user_25" in text or "yoon" in text:
            print(f"Store: {snap.get('data_store')}, Coll: {snap.get('collection')}: {rec}")
