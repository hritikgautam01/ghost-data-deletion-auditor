import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
print(reqs[reqs["case_id"].isin(["case_31", "case_32"])].to_dict(orient="records"))
