import sys, json
sys.path.insert(0, '.')
from code.src.pipeline import AuditPipeline

pipeline = AuditPipeline()
res = pipeline.process_case("case_14")
print("Status:", res.deletion_status)
print("Steps:")
for s in json.loads(res.steps_json):
    print(" ", s)
