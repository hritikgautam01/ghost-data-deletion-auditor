import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

act = pd.read_csv(dataset_dir / "system_activity.csv")
print(f"Total system activities: {len(act)}")
print("Sample details:")
for d in act["details"].dropna().sample(20, random_state=42):
    print(" -", d)
