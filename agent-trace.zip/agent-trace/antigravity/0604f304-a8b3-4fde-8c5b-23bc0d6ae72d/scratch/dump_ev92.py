import json
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

fpath = dataset_dir / "evidence/records/service_resource_export_20260915_114455.json"
with open(fpath, "r", encoding="utf-8") as f:
    data = json.load(f)

for sname, sdata in data["service_exports"].items():
    print(f"\n=== SERVICE: {sname} ===")
    for cname, items in sdata.items():
        print(f"Collection: {cname} (count={len(items)})")
        for it in items:
            print("  ", it)
