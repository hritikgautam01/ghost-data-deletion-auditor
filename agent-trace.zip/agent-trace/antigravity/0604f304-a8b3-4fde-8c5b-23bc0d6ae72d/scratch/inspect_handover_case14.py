from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

with open(dataset_dir / "evidence/records/customer_account_handover_20261001.txt") as f:
    text = f.read()

for line in text.splitlines():
    if any(k in line for k in ["tanaka", "3870", "3677", "987", "user_37"]):
        print(line)
