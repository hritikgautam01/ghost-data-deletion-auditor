import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, "c:/Users/hriti/Documents/Orchestrate")
from src.data.loader import find_dataset_dir
from src.pipeline import AuditPipeline

base_dir = find_dataset_dir()
pipeline = AuditPipeline(dataset_dir=base_dir)
sample_cases = pipeline.bundle.sample_deletion_requests

results = pipeline.process_all(sample_cases)
preds = {r.case_id: json.loads(r.steps_json) for r in results}

truth_p = base_dir / "sample_output.csv"
with open(truth_p, encoding="utf-8") as f:
    truth = {r["case_id"]: json.loads(r["steps_json"]) for r in csv.DictReader(f)}

for cid in sorted(truth.keys()):
    t_steps = truth[cid]
    p_steps = preds.get(cid, [])
    if t_steps != p_steps:
        # Check if the set of (phase, op, sys, res) is the same
        t_set = [(s['phase'], s['operation'], s['system_id'], s['resource_id']) for s in t_steps]
        p_set = [(s['phase'], s['operation'], s['system_id'], s['resource_id']) for s in p_steps]
        if t_set == p_set:
            print(f"[{cid}] EXACT SAME STEPS, DIFFERENT ORDER OR EVIDENCE ID:")
            for idx, (t, p) in enumerate(zip(t_steps, p_steps), 1):
                if t != p:
                    print(f"   Step {idx} differs:")
                    print(f"     Truth: {t}")
                    print(f"     Pred : {p}")
        else:
            print(f"[{cid}] DIFFERENT STEP SET:")
            t_only = set(t_set) - set(p_set)
            p_only = set(p_set) - set(t_set)
            if t_only:
                print(f"   Truth only: {t_only}")
            if p_only:
                print(f"   Pred only : {p_only}")
