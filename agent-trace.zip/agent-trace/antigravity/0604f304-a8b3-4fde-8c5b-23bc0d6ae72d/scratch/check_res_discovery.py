import pandas as pd
import json

reqs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_deletion_requests.csv')
outs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_output.csv')
acts = pd.read_csv('hackerrank-orchestrate-october26/dataset/system_activity.csv')
users = pd.read_csv('hackerrank-orchestrate-october26/dataset/user_identities.csv')
audits = pd.read_csv('hackerrank-orchestrate-october26/dataset/user_audit_log.csv')

email_to_user = {row['email'].strip().lower(): row['user_id'] for _, row in users.iterrows()}
for _, row in audits[audits['field_name']=='email'].iterrows():
    if pd.notna(row['old_value']):
        email_to_user[row['old_value'].strip().lower()] = row['user_id']
    if pd.notna(row['new_value']):
        email_to_user[row['new_value'].strip().lower()] = row['user_id']

acts['dt'] = pd.to_datetime(acts['event_time'])

merged = pd.merge(reqs, outs, on='case_id')
for idx, r in merged.iterrows():
    cid = r['case_id']
    em = r['email'].strip().lower()
    uid = email_to_user.get(em)
    steps = json.loads(r['steps_json'])
    gold_resources = {s['resource_id']: (s['system_id'], s['operation']) for s in steps}
    
    # Check acts around reported_at
    rep_dt = pd.to_datetime(r['reported_at'])
    act_window = acts[(acts['dt'] >= rep_dt - pd.Timedelta(hours=4)) & (acts['dt'] <= rep_dt + pd.Timedelta(hours=4))]
    act_res = set(act_window['resource_id'].dropna())
    
    # Check acts mentioning user_id or email
    user_acts = acts[acts['details'].str.contains(uid, na=False) | acts['details'].str.contains(em, na=False)]
    user_act_res = set(user_acts['resource_id'].dropna())
    
    found_in_window = set(gold_resources.keys()).intersection(act_res)
    found_in_user_acts = set(gold_resources.keys()).intersection(user_act_res)
    
    print(f"{cid} ({uid}): gold={list(gold_resources.keys())}")
    print(f"   found in window (+/- 4h): {list(found_in_window)}")
    print(f"   found in user acts: {list(found_in_user_acts)}")
    missing = set(gold_resources.keys()) - (found_in_window | found_in_user_acts)
    if missing:
        print(f"   MISSING from acts: {list(missing)}")
