import csv
import random
from pathlib import Path
import sys
sys.path.insert(0, "c:/Users/hriti/Documents/Orchestrate")
from src.nlp.intent import IntentClassifier

csv_path = Path("hackerrank-orchestrate-october26/dataset/deletion_requests.csv")
with open(csv_path, "r", encoding="utf-8") as f:
    requests = list(csv.DictReader(f))

del_cases = [r for r in requests if IntentClassifier.is_deletion_request(r["request_text"])]
random.seed(42)
sampled = random.sample(del_cases, 60)

for idx, r in enumerate(sampled, 1):
    cid = r["case_id"]
    txt = r["request_text"]
    print(f"{idx:02d}. [{cid}] {txt}")
