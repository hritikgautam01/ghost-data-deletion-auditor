import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, "c:/Users/hriti/Documents/Orchestrate")
from src.data.loader import find_dataset_dir
from src.pipeline import AuditPipeline

base_dir = find_dataset_dir()
pipeline = AuditPipeline(dataset_dir=base_dir)
sample_cases = pipeline.bundle.sample_deletion_requests

# Run pipeline
results = pipeline.process_all(sample_cases)
preds = {r.case_id: json.loads(r.steps_json) for r in results}

truth_p = base_dir / "sample_output.csv"
with open(truth_p, encoding="utf-8") as f:
    truth = {r["case_id"]: json.loads(r["steps_json"]) for r in csv.DictReader(f)}

mismatches = []
for cid, t_steps in truth.items():
    p_steps = preds.get(cid, [])
    if t_steps != p_steps:
        mismatches.append((cid, t_steps, p_steps))

print(f"Total sequence mismatches: {len(mismatches)}")
for cid, t_steps, p_steps in mismatches:
    print(f"\n================ Case: {cid} ================")
    print("TRUTH STEPS:")
    for s in t_steps:
        print(f"  {s['step_no']}. {s['phase']} | {s['operation']} | {s['system_id']} | {s['resource_id']} | {s['state']} | {s['evidence_id']}")
    print("PREDICTED STEPS:")
    for s in p_steps:
        print(f"  {s['step_no']}. {s['phase']} | {s['operation']} | {s['system_id']} | {s['resource_id']} | {s['state']} | {s['evidence_id']}")
