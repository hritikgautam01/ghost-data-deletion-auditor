import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

act = pd.read_csv(dataset_dir / "system_activity.csv")
print(act[(act["activity_id"] >= "activity_3340") & (act["activity_id"] <= "activity_3360")][["activity_id", "event_time", "event_type", "target_system", "resource_id", "reported_result", "details"]].to_string())
