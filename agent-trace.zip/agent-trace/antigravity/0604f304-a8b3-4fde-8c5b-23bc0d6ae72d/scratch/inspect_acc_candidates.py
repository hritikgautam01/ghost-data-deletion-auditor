import json
import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

sample_out = pd.read_csv(dataset_dir / "sample_output.csv")
sample_reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
act = pd.read_csv(dataset_dir / "system_activity.csv")
act["dt"] = pd.to_datetime(act["event_time"])

# Filter deletion worker activities for account_service
acc_acts = act[(act["source_system"] == "deletion_worker") & (act["target_system"] == "account_service") & (act["event_type"] == "DELETE_RECORD")]

for _, row in sample_out.iterrows():
    cid = row["case_id"]
    steps = json.loads(row["steps_json"])
    req = sample_reqs[sample_reqs["case_id"] == cid].iloc[0]
    
    gt_accs = [s["resource_id"] for s in steps if s["system_id"] == "account_service"]
    gt_acc = gt_accs[0] if gt_accs else None
    
    rep_at = pd.to_datetime(req["reported_at"])
    req_at = pd.to_datetime(req["requested_at"])
    
    # candidate activities between req_at and rep_at
    cands = acc_acts[(acc_acts["dt"] >= req_at) & (acc_acts["dt"] <= rep_at)]
    
    print(f"\n{cid} (req={req_at}, rep={rep_at}) -> GT acc: {gt_acc}:")
    for _, a in cands.iterrows():
        is_match = (a["resource_id"] == gt_acc)
        marker = "===> MATCH" if is_match else ""
        print(f"  {a['activity_id']} {a['event_time']} {a['resource_id']} {a['reported_result']} {marker}")
