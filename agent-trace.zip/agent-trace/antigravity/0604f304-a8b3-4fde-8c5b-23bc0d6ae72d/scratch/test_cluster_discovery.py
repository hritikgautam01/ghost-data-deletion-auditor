import json
import pandas as pd
from pathlib import Path
from datetime import timedelta

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

sample_out = pd.read_csv(dataset_dir / "sample_output.csv")
sample_reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
act = pd.read_csv(dataset_dir / "system_activity.csv")
act["dt"] = pd.to_datetime(act["event_time"])

del_acts = act[act["source_system"] == "deletion_worker"]

for _, row in sample_out.iterrows():
    cid = row["case_id"]
    steps = json.loads(row["steps_json"])
    gt_resources = list(dict.fromkeys(s["resource_id"] for s in steps))
    
    req = sample_reqs[sample_reqs["case_id"] == cid].iloc[0]
    rep_at = pd.to_datetime(req["reported_at"])
    
    # Let's inspect activities within 2 hours before reported_at up to 2 hours after
    w_acts = del_acts[(del_acts["dt"] >= rep_at - pd.Timedelta(hours=2)) & (del_acts["dt"] <= rep_at + pd.Timedelta(hours=2))]
    
    res_list = list(dict.fromkeys(w_acts["resource_id"]))
    print(f"\n{cid} ({req['email']}) rep_at={rep_at}:")
    print(f"  GT: {gt_resources}")
    print(f"  All Del Acts in Window: {res_list}")
