import json
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

with open(dataset_dir / "evidence" / "records" / "customer_data_snapshot_bundle_20260915.json") as f:
    ev51 = json.load(f)

print("ev51 type:", type(ev51))
if isinstance(ev51, dict):
    print("keys:", list(ev51.keys()))
    for k in ev51:
        val = ev51[k]
        if isinstance(val, list):
            print(f"Key {k} is list of length {len(val)}")
            for item in val[:3]:
                print("  item sample:", item)
