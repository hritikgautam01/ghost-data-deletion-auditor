import os, glob
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

for fpath in glob.glob(str(dataset_dir / "**" / "*"), recursive=True):
    if os.path.isfile(fpath) and not fpath.endswith((".png", ".pdf", ".pyc")):
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
                if "account_7012" in content:
                    print(f"Found account_7012 in: {fpath}")
        except Exception:
            pass
