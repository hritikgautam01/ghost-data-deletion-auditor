import pandas as pd
import json

reqs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_deletion_requests.csv')
outs = pd.read_csv('hackerrank-orchestrate-october26/dataset/sample_output.csv')
acts = pd.read_csv('hackerrank-orchestrate-october26/dataset/system_activity.csv')

acts['dt'] = pd.to_datetime(acts['event_time'])
reqs['req_dt'] = pd.to_datetime(reqs['requested_at'])
reqs['rep_dt'] = pd.to_datetime(reqs['reported_at'])

for idx, r in reqs.head(10).iterrows():
    cid = r['case_id']
    sub = acts[(acts['dt'] >= r['req_dt'] - pd.Timedelta(hours=1)) & (acts['dt'] <= r['rep_dt'] + pd.Timedelta(hours=1))]
    out_row = outs[outs['case_id'] == cid].iloc[0]
    steps = json.loads(out_row['steps_json'])
    out_resources = [s['resource_id'] for s in steps]
    print(f"=== {cid} ({r['email']}) reported_status={r['reported_status']} ===")
    print(f"    Target resources in sample_output: {out_resources}")
    
    # Check if activities in this window mention any of the resources
    matching_acts = sub[sub['resource_id'].isin(out_resources)]
    for _, a in matching_acts.iterrows():
        print(f"    Matched act: {a['activity_id']} {a['event_time']} {a['event_type']} {a['target_system']} {a['resource_id']} {a['reported_result']}")
