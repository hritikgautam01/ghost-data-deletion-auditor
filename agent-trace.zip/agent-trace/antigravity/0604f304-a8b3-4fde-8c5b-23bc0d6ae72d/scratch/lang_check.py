import csv
import re
from pathlib import Path

csv_path = Path("hackerrank-orchestrate-october26/dataset/deletion_requests.csv")
with open(csv_path, "r", encoding="utf-8") as f:
    requests = list(csv.DictReader(f))

# Check for non-English texts
non_en_patterns = {
    "Japanese": re.compile(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]"),
    "Korean": re.compile(r"[\uac00-\ud7af]"),
    "Spanish": re.compile(r"\b(?:solicito|eliminación|cuenta|correo|revisen|según|política)\b", re.I),
    "French": re.compile(r"\b(?:demande|suppression|définitive|compte|associé|adresse|procédure)\b", re.I),
    "Portuguese": re.compile(r"\b(?:exclusão|e-mail|identificadores|anteriores|conforme|análise)\b", re.I),
    "German": re.compile(r"\b(?:löschen|Löschung|Konto|Datenschutz|DSGVO|schließen)\b", re.I)
}

counts = {k: 0 for k in non_en_patterns}
counts["English"] = 0

for r in requests:
    t = r["request_text"]
    matched = False
    for lang, pat in non_en_patterns.items():
        if pat.search(t):
            counts[lang] += 1
            matched = True
            break
    if not matched:
        counts["English"] += 1

print("Accurate Language Breakdown:")
for lang, cnt in counts.items():
    print(f"  {lang}: {cnt}")
