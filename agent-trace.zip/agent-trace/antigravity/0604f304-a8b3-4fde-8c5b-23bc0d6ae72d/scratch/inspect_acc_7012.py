import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

act = pd.read_csv(dataset_dir / "system_activity.csv")
print(act[act["resource_id"] == "account_7012"].to_dict(orient="records"))
