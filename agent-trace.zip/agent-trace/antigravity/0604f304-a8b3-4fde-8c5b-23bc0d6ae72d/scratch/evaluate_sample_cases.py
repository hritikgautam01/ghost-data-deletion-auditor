import sys, json
import pandas as pd
sys.path.insert(0, '.')

from code.src.pipeline import AuditPipeline

pipeline = AuditPipeline()
sample_requests = pipeline.bundle.sample_deletion_requests
sample_truth = {r.case_id: r for r in pipeline.bundle.sample_output}

print(f"Running pipeline on {len(sample_requests)} sample cases...")

matches_status = 0
matches_steps_exact = 0
total = len(sample_requests)

for req in sample_requests:
    res = pipeline.process_case(req)
    truth = sample_truth.get(req.case_id)
    
    if not truth:
        print(f"Warning: No ground truth for {req.case_id}")
        continue
        
    status_match = res.deletion_status == truth.deletion_status
    if status_match:
        matches_status += 1
        
    # Compare steps
    pred_steps = json.loads(res.steps_json)
    truth_steps = json.loads(truth.steps_json)
    
    steps_match = (pred_steps == truth_steps)
    if steps_match:
        matches_steps_exact += 1
    else:
        print(f"\n--- Mismatch in {req.case_id} ---")
        print(f"  Pred Status: {res.deletion_status} | Truth Status: {truth.deletion_status}")
        print(f"  Pred Steps ({len(pred_steps)}):")
        for s in pred_steps:
            print(f"    [{s['step_no']}] {s['phase']} {s['system_id']} {s['resource_id']} {s['operation']} {s['state']} ev='{s['evidence_id']}'")
        print(f"  Truth Steps ({len(truth_steps)}):")
        for s in truth_steps:
            print(f"    [{s['step_no']}] {s['phase']} {s['system_id']} {s['resource_id']} {s['operation']} {s['state']} ev='{s['evidence_id']}'")

print(f"\nSummary:")
print(f"Status Accuracy: {matches_status}/{total} ({matches_status/total*100:.1f}%)")
print(f"Exact Steps Accuracy: {matches_steps_exact}/{total} ({matches_steps_exact/total*100:.1f}%)")
