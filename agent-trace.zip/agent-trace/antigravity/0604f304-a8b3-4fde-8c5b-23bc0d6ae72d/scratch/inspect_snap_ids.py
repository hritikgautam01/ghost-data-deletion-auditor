import json
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

fpath = dataset_dir / "evidence/records/customer_data_snapshot_bundle_20260917.json"
with open(fpath, "r", encoding="utf-8") as f:
    data = json.load(f)

for snap in data.get("snapshots", []):
    for rec in snap.get("records", []):
        rid = rec.get("resource_id", "")
        if rid in ["account_3866", "account_5482", "account_7012", "analytics_4574", "analytics_6077", "audit_record_3954"]:
            print(f"Store: {snap.get('data_store')}, Coll: {snap.get('collection')}: {rec}")
