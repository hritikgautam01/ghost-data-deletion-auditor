import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

act = pd.read_csv(dataset_dir / "system_activity.csv")
acts = act[(act["event_time"] >= "2026-08-30T10:40:00Z") & (act["event_time"] <= "2026-08-30T14:00:00Z")]
print(acts[["activity_id", "event_time", "event_type", "source_system", "target_system", "resource_id", "reported_result", "details"]].to_string())
