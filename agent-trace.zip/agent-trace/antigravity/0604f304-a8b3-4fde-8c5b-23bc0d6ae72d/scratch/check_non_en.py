import csv
import re
from pathlib import Path

csv_path = Path("hackerrank-orchestrate-october26/dataset/deletion_requests.csv")
with open(csv_path, "r", encoding="utf-8") as f:
    requests = list(csv.DictReader(f))

non_en_patterns = {
    "Japanese": re.compile(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]"),
    "Korean": re.compile(r"[\uac00-\ud7af]"),
    "Spanish": re.compile(r"\b(?:solicito|eliminación|cuenta|correo|revisen|según|política)\b", re.I),
    "French": re.compile(r"\b(?:demande|suppression|définitive|compte|associé|adresse|procédure)\b", re.I),
}

for lang, pat in non_en_patterns.items():
    print(f"\n=== Samples of {lang} requests ===")
    matches = [r for r in requests if pat.search(r["request_text"])]
    print(f"Total {lang}: {len(matches)}")
    # Print unique texts
    unique_texts = set(r["request_text"] for r in matches)
    for u in unique_texts:
        print(f"  - {u}")
