with open('hackerrank-orchestrate-october26/dataset/evidence/logs/resource_lookup_trace_20260926_103856.log') as f:
    lines = f.readlines()

traces = {}
for line in lines:
    parts = line.strip().split()
    kv = {}
    for p in parts:
        if '=' in p:
            k, v = p.split('=', 1)
            kv[k] = v.strip('"')
    tid = kv.get('trace_id')
    if tid:
        traces.setdefault(tid, []).append(kv)

print('Total traces in evidence_94:', len(traces))
for tid, items in list(traces.items())[:15]:
    subjects = [it.get('lookup_key') or it.get('subject_key') or it.get('subject_ref') or it.get('correlation_key') or it.get('matched_value') for it in items]
    subjects = [s for s in subjects if s]
    res_ids = [it.get('resource_id') for it in items if it.get('resource_id')]
    events = [it.get('event') for it in items if it.get('event')]
    if subjects:
        print(f"Trace {tid}: subject={subjects} -> res={res_ids} events={events}")
