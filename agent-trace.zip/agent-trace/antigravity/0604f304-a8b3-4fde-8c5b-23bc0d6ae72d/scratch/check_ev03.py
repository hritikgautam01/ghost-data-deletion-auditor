import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

ev = pd.read_csv(dataset_dir / "evidence_files.csv")
print(ev[ev["file_id"] == "evidence_03"].to_dict(orient="records"))
