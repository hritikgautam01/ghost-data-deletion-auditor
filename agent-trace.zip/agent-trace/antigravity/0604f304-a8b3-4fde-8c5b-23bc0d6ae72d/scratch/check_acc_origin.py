import json, os, glob
import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

sample_out = pd.read_csv(dataset_dir / "sample_output.csv")
sample_reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
users_df = pd.read_csv(dataset_dir / "user_identities.csv")
user_map = {r["email"]: r["user_id"] for _, r in users_df.iterrows()}
act = pd.read_csv(dataset_dir / "system_activity.csv")

for _, row in sample_out.iterrows():
    cid = row["case_id"]
    steps = json.loads(row["steps_json"])
    req = sample_reqs[sample_reqs["case_id"] == cid].iloc[0]
    email = req["email"]
    uid = user_map.get(email)
    
    # Find account_XXXX in steps
    acc_res = [s["resource_id"] for s in steps if s["system_id"] == "account_service"]
    if not acc_res:
        continue
    target_acc = acc_res[0]
    
    # Check where target_acc appears
    # 1. in system_activity.csv
    acts = act[act["resource_id"] == target_acc]
    act_info = []
    if len(acts) > 0:
        for _, a in acts.iterrows():
            act_info.append(f"{a['activity_id']} ({a['event_time']}, {a['event_type']}, {a['reported_result']})")
    
    print(f"{cid} (email={email}, uid={uid}) -> {target_acc}:")
    print(f"  Activities: {act_info}")
