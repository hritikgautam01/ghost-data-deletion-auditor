import json
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

fpath = dataset_dir / "evidence/records/service_resource_export_20260915_114455.json"
with open(fpath, "r", encoding="utf-8") as f:
    data = json.load(f)

exports = data["service_exports"]
print("Services in exports:", list(exports.keys()))
for sname, sdata in exports.items():
    print(f"\nService {sname}:")
    if isinstance(sdata, dict):
        print("  dict keys:", list(sdata.keys()))
        for k, v in sdata.items():
            if isinstance(v, list):
                print(f"    {k}: len={len(v)}")
                if len(v) > 0:
                    print(f"      sample: {v[0]}")
    elif isinstance(sdata, list):
        print(f"  list len={len(sdata)}")
        if len(sdata) > 0:
            print(f"    sample: {sdata[0]}")
