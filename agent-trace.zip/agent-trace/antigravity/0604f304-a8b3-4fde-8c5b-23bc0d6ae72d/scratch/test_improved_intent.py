import re, sys
import pandas as pd
from pathlib import Path

# Explicit non-deletion phrases
NON_DEL_PATTERNS = [
    r'not\s+(?:asking\s+for|a\s+request\s+for)\s+(?:deletion|erasure|delete)',
    r'(?:don\'t|do\s+not)\s+(?:delete|close|remove)',
    r'leave\s+(?:the\s+account|my\s+profile|my\s+records)\s+(?:active|as\s+it\s+is|in\s+place)',
    r'keep\s+the\s+account\s+as\s+it\s+is',
    r'continue\s+using\s+the\s+service',
    r'correct\s+it\s+without\s+removing',
    r'remove\s+me\s+from\s+marketing\s+lists\s+only',
    r'stop\s+the\s+promotional\s+emails',
    r'resetting\s+the\s+login',
    r'information\s+request,\s+not\s+a\s+request',
    r'send\s+me\s+a\s+copy.*don\'t\s+delete',
    r'download\s+my\s+account\s+information.*keep',
    r'mobile\s+number.*replace\s+it.*leave\s+the\s+account',
    r'change\s+the\s+email\s+address.*continue\s+using',
]
NON_DEL_RE = re.compile('|'.join(NON_DEL_PATTERNS), re.IGNORECASE)

DEL_PATTERNS = [
    r'\b(?:delet(?:e|ed|ing|ion|ions)?|eras(?:e|ed|ing|ure)?|remov(?:e|ed|ing|al|als)?|purg(?:e|ed|ing)?|wip(?:e|ed|ing)?)\b',
    r'\b(?:close|closed|closing)\s+(?:my|this|the)?\s*account\b',
    r'\b(?:account|profile)\s+is\s+gone\b',
    r'\bright\s+to\s+be\s+forgotten\b',
    r'\b(?:eliminar|eliminaci[oó]n|borrar|borrado|suprimir|supresi[oó]n|cerrar\s+(?:mi|la)\s+cuenta)\b',
    r'\b(?:suppression|supprimer|effacer|effacement|fermer\s+(?:mon|le)\s+compte|droit\s+[aà]\s+l\'oubli)\b',
    r'\b(?:excluir|exclus[aã]o|apagar|eliminar|deletar|fechar\s+(?:minha|a)\s+conta)\b',
    r'\b(?:l[oö]schen|l[oö]schung|entfernen|entfernung|konto\s+schlie[ßs]en)\b',
    r'(?:削除|消去|抹消|アカウント.*閉鎖|退会|消して)',
    r'(?:삭제|파기|제거|탈퇴|계정.*폐쇄)',
]
DEL_RE = re.compile('|'.join(DEL_PATTERNS), re.IGNORECASE)

def is_deletion(txt):
    if not txt:
        return False
    if NON_DEL_RE.search(txt):
        return False
    return bool(DEL_RE.search(txt))

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

# Test on 32 samples (all must be True)
sample_reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
sample_fails = 0
for _, r in sample_reqs.iterrows():
    res = is_deletion(r["request_text"])
    if not res:
        print(f"Sample failed ({r['case_id']}): {r['request_text']}")
        sample_fails += 1
print(f"Sample failures: {sample_fails} / 32")

# Test on case_530..550 in deletion_requests.csv
eval_reqs = pd.read_csv(dataset_dir / "deletion_requests.csv")
tail = eval_reqs[(eval_reqs["case_id"] >= "case_533") & (eval_reqs["case_id"] <= "case_542")]
non_del_detected = 0
for _, r in tail.iterrows():
    res = is_deletion(r["request_text"])
    if not res:
        non_del_detected += 1
    else:
        print(f"Eval non-del failed ({r['case_id']}): {r['request_text']}")
print(f"Non-del detected: {non_del_detected} / {len(tail)}")
