import json, os
import pandas as pd
from pathlib import Path

# find dataset dir
for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

df = pd.read_csv(dataset_dir / "sample_output.csv")
requests_df = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
req_map = {r["case_id"]: r for _, r in requests_df.iterrows()}

for _, row in df.iterrows():
    cid = row["case_id"]
    status = row["deletion_status"]
    steps = json.loads(row["steps_json"])
    req = req_map.get(cid, {})
    
    print(f"\n=== {cid} | Status: {status} | Email: {req.get('email')} | Reported: {req.get('reported_status')} ===")
    print(f"Text: {str(req.get('request_text'))[:60]}...")
    for s in steps:
        print(f"  [{s['step_no']}] {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | ev='{s['evidence_id']}'")
