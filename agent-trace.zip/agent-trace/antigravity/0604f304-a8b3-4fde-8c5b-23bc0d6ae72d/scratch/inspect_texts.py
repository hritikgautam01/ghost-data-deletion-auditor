import csv
from pathlib import Path
from collections import Counter

csv_path = Path("hackerrank-orchestrate-october26/dataset/deletion_requests.csv")
with open(csv_path, "r", encoding="utf-8") as f:
    requests = list(csv.DictReader(f))

# Let's inspect the unique request texts or sentence structures
unique_texts = Counter(r["request_text"] for r in requests)
print(f"Total requests: {len(requests)}")
print(f"Total unique request_text values: {len(unique_texts)}")

# Print the top 10 most frequent request texts
print("\nTop 5 request texts:")
for txt, cnt in unique_texts.most_common(5):
    print(f"  Count {cnt}: {txt[:80]}...")

# Check language distribution or non-English requests
languages = []
for r in requests:
    t = r["request_text"]
    if any(c in t for c in "アカウント削除消去"):
        languages.append("Japanese")
    elif any(c in t for c in "삭제파기"):
        languages.append("Korean")
    elif any(c in t for c in "supprimerdéfinitivement"):
        languages.append("French")
    elif any(c in t for c in "löschenLöschung"):
        languages.append("German")
    elif any(c in t for c in "eliminacióneliminar"):
        languages.append("Spanish")
    elif any(c in t for c in "exclusãoexcluir"):
        languages.append("Portuguese")
    else:
        languages.append("English")

print("\nLanguage breakdown:")
for lang, cnt in Counter(languages).items():
    print(f"  {lang}: {cnt}")
