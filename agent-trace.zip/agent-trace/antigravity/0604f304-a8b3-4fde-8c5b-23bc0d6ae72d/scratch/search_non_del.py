import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

reqs = pd.read_csv(dataset_dir / "deletion_requests.csv")

non_del = []
for _, r in reqs.iterrows():
    txt = r["request_text"].lower()
    if any(k in txt for k in ["access", "export", "download", "rectif", "opt-out", "unsubscribe", "newsletter"]):
        non_del.append((r["case_id"], r["request_text"]))

print(f"Found {len(non_del)} possible non-deletion requests:")
for cid, txt in non_del[:10]:
    print(f"\n{cid}: {txt}")
