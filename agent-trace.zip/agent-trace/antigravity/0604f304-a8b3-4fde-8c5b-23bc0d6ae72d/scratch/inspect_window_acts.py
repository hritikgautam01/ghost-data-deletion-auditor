import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

act = pd.read_csv(dataset_dir / "system_activity.csv")
acts_around = act[(act["event_time"] >= "2026-09-02T10:00:00Z") & (act["event_time"] <= "2026-09-02T12:00:00Z")]
print(acts_around.to_dict(orient="records"))
