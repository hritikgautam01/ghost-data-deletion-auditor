import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
out = pd.read_csv(dataset_dir / "sample_output.csv")
truth = dict(zip(out["case_id"], out["deletion_status"]))

for _, r in reqs.iterrows():
    cid = r["case_id"]
    st = truth[cid]
    if st == "NOT_APPLICABLE":
        print(f"=== {cid} (NOT_APPLICABLE) ===")
        print(f"Text: {r['request_text']}\n")
