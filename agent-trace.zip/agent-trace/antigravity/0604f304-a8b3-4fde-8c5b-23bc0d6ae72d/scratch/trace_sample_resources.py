import json, os, glob
import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

sample_out = pd.read_csv(dataset_dir / "sample_output.csv")
sample_reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
users_df = pd.read_csv(dataset_dir / "user_identities.csv")
user_map = {r["email"]: r["user_id"] for _, r in users_df.iterrows()}

all_res = []
for _, row in sample_out.iterrows():
    cid = row["case_id"]
    steps = json.loads(row["steps_json"])
    req = sample_reqs[sample_reqs["case_id"] == cid].iloc[0]
    email = req["email"]
    uid = user_map.get(email)
    
    for s in steps:
        all_res.append({
            "case_id": cid,
            "user_id": uid,
            "email": email,
            "system_id": s["system_id"],
            "resource_id": s["resource_id"],
            "operation": s["operation"],
            "phase": s["phase"],
            "evidence_id": s["evidence_id"]
        })

df_res = pd.DataFrame(all_res)
print(f"Total steps in sample_output: {len(df_res)}")
print(f"Unique resources in sample_output: {df_res['resource_id'].nunique()}")

# Let's inspect where these resources appear
print("\nFirst 20 resources in sample output:")
print(df_res[["case_id", "user_id", "system_id", "resource_id", "operation", "evidence_id"]].head(20).to_string())
