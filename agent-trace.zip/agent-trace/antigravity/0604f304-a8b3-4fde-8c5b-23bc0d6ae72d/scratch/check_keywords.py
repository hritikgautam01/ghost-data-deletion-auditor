import csv
import re
import sys
from pathlib import Path

sys.path.insert(0, "c:/Users/hriti/Documents/Orchestrate")
from src.nlp.intent import IntentClassifier

csv_path = Path("hackerrank-orchestrate-october26/dataset/deletion_requests.csv")
with open(csv_path, "r", encoding="utf-8") as f:
    requests = list(csv.DictReader(f))

keywords = [
    "access", "copy", "export", "download", "correct", "update", "rectify",
    "unsubscribe", "opt out", "newsletter", "don't delete", "do not delete",
    "keep my account", "not asking"
]

patterns = [re.escape(k) for k in keywords]
combined_regex = re.compile(r"|".join(patterns), re.IGNORECASE)

keyword_hits = []
for r in requests:
    cid = r["case_id"]
    txt = r["request_text"]
    found = combined_regex.findall(txt)
    if found:
        is_del = IntentClassifier.is_deletion_request(txt)
        keyword_hits.append((cid, txt, set(x.lower() for x in found), is_del))

print(f"Total requests containing any keyword: {len(keyword_hits)}")
del_hits = [h for h in keyword_hits if h[3]]
non_del_hits = [h for h in keyword_hits if not h[3]]

print(f"Classified as DELETION: {len(del_hits)}")
print(f"Classified as NOT_APPLICABLE: {len(non_del_hits)}")

print("\n=== KEYWORD HITS CLASSIFIED AS DELETION ===")
for cid, txt, matched, _ in del_hits:
    print(f"[{cid}] Matched: {matched}")
    print(f"  Text: {txt}")

print("\n=== KEYWORD HITS CLASSIFIED AS NOT_APPLICABLE ===")
for cid, txt, matched, _ in non_del_hits:
    print(f"[{cid}] Matched: {matched}")
    print(f"  Text: {txt}")
