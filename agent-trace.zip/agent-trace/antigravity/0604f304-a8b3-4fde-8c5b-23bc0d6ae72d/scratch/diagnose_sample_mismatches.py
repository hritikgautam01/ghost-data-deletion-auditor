import sys, json
sys.path.insert(0, '.')
from code.src.pipeline import AuditPipeline

pipe = AuditPipeline()
sample_requests = pipe.bundle.sample_deletion_requests
sample_truth = {r.case_id: r for r in pipe.bundle.sample_output}

mismatches = []
for c in sample_requests:
    res = pipe.process_case(c)
    t = sample_truth.get(c.case_id)
    pred_steps = json.loads(res.steps_json)
    truth_steps = json.loads(t.steps_json)
    status_match = (res.deletion_status == t.deletion_status)
    steps_match = (pred_steps == truth_steps)
    if not status_match or not steps_match:
        mismatches.append((c, res, t, pred_steps, truth_steps, status_match, steps_match))

print(f"Total Mismatches: {len(mismatches)} / {len(sample_requests)}")
for c, res, t, pred_steps, truth_steps, status_match, steps_match in mismatches:
    print(f"\n=== {c.case_id} ===")
    print(f"  User Email:   {c.email}")
    print(f"  Requested:    {c.requested_at}")
    print(f"  Reported:     {c.reported_at} ({c.reported_status})")
    print(f"  Audit Cutoff: {c.audit_at}")
    print(f"  Status Match: {status_match} (Pred: {res.deletion_status} vs Truth: {t.deletion_status})")
    print(f"  Steps Match:  {steps_match}")
    pred_summary = [f"{s['phase']}:{s['resource_id']}:{s['operation']}" for s in pred_steps]
    truth_summary = [f"{s['phase']}:{s['resource_id']}:{s['operation']}" for s in truth_steps]
    print(f"  Pred  ({len(pred_steps)}): {pred_summary}")
    print(f"  Truth ({len(truth_steps)}): {truth_summary}")
    
    # Missing from pred
    diff_missing = set(truth_summary) - set(pred_summary)
    if diff_missing:
        print(f"  MISSING from Pred: {diff_missing}")
    # Extra in pred
    diff_extra = set(pred_summary) - set(truth_summary)
    if diff_extra:
        print(f"  EXTRA in Pred:    {diff_extra}")
