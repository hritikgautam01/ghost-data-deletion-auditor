import json
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

fpath = dataset_dir / "evidence/records/service_resource_export_20260915_114455.json"
with open(fpath, "r", encoding="utf-8") as f:
    data = json.load(f)

print("Type:", type(data))
if isinstance(data, dict):
    print("Keys:", list(data.keys()))
    for k in data:
        val = data[k]
        print(f"Key {k}: type={type(val)}, len={len(val) if hasattr(val, '__len__') else 'N/A'}")
        if isinstance(val, list) and len(val) > 0:
            print("  sample item:", val[0])
elif isinstance(data, list):
    print("Len:", len(data))
    print("Sample 0:", data[0])
