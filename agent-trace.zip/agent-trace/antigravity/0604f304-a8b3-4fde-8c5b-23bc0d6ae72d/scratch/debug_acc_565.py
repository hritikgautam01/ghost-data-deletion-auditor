import sys
sys.path.insert(0, '.')
from code.src.data.loader import find_dataset_dir, load_dataset_bundle
from code.src.identity.resolver import IdentityResolver
from code.src.evidence.manifest import EvidenceManifest
from code.src.evidence.log_parser import extract_log_records_from_file

base_dir = find_dataset_dir()
bundle = load_dataset_bundle(base_dir)
resolver = IdentityResolver(bundle.user_identities, bundle.user_audit_log, dataset_dir=base_dir)
req = [r for r in bundle.sample_deletion_requests if r.case_id == 'case_09'][0]
subj = resolver.resolve(req)

manifest = EvidenceManifest(base_dir)
ev6 = manifest.get_by_id('evidence_06')
res = extract_log_records_from_file(ev6, dataset_dir=base_dir)

print("Subj emails:", subj.all_emails)
print("Subj user_ids:", subj.primary_user_id)

traces = set()
for r in res.records:
    tid = r.raw_payload.get("trace_id")
    # check matches
    u = r.identifiers.get("user_id")
    e = r.identifiers.get("email")
    payload = r.raw_payload
    is_match = False
    if u and subj.matches_identifier("user_id", u): is_match = True
    if e and subj.matches_identifier("email", e): is_match = True
    for k in ("lookup_key", "subject_key", "subject_ref", "subject_reference"):
        v = payload.get(k)
        if v and isinstance(v, str) and (subj.matches_identifier("email", v.strip().lower()) or subj.matches_identifier("user_id", v.strip().lower())):
            is_match = True
    if is_match and tid:
        traces.add(tid)
        print(f"Matched trace: {tid} on {payload}")

for r in res.records:
    if r.resource_id in ("account_565", "account_3960"):
        tid = r.raw_payload.get("trace_id")
        print(f"Record {r.resource_id}: tid={tid}, in_traces={tid in traces}")
