import csv
import re
from pathlib import Path

csv_path = Path("hackerrank-orchestrate-october26/dataset/deletion_requests.csv")
with open(csv_path, "r", encoding="utf-8") as f:
    requests = list(csv.DictReader(f))

# Keywords excluding 'correct'
keywords = [
    "access", "copy", "export", "download", "update", "rectify",
    "unsubscribe", "opt out", "newsletter", "don't delete", "do not delete",
    "keep my account", "not asking"
]

patterns = [re.escape(k) for k in keywords]
combined_regex = re.compile(r"|".join(patterns), re.IGNORECASE)

found_any = False
for r in requests:
    cid = r["case_id"]
    txt = r["request_text"]
    matches = combined_regex.findall(txt)
    c_num = int(cid.split("_")[1])
    if matches and not (533 <= c_num <= 542):
        print(f"FOUND IN DELETION CASE [{cid}] (matches: {set(m.lower() for m in matches)}):")
        print(f"  {txt}")
        found_any = True

if not found_any:
    print("ZERO requests outside of case_533-542 matched ANY of the non-deletion keywords!")
