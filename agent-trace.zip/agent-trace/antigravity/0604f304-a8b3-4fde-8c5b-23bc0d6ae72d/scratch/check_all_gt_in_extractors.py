import sys
sys.path.insert(0, '.')
import json, os, glob
import pandas as pd
from pathlib import Path

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

from code.src.evidence.manifest import EvidenceManifest
from code.src.evidence.json_extractor import extract_from_file
from code.src.evidence.log_parser import extract_log_records_from_file
from code.src.evidence.sql_engine import extract_sql_records_from_file
from code.src.evidence.doc_extractor import extract_doc_records_from_file

manifest = EvidenceManifest(dataset_dir)
all_ev_records = []
for entry in manifest.get_all_entries():
    p = entry.file_path.lower()
    if p.endswith(".json"):
        r = extract_from_file(entry, dataset_dir)
    elif p.endswith((".log", ".txt")):
        r = extract_log_records_from_file(entry, dataset_dir)
    elif p.endswith(".sql"):
        r = extract_sql_records_from_file(entry, dataset_dir)
    elif p.endswith((".pdf", ".png")):
        r = extract_doc_records_from_file(entry, dataset_dir)
    else:
        continue
    if r.success:
        all_ev_records.extend(r.records)

print(f"Total extracted evidence records across all 35 manifest files: {len(all_ev_records)}")

# Index extracted records by resource_id
res_to_records = {}
for r in all_ev_records:
    if r.resource_id:
        res_to_records.setdefault(r.resource_id, []).append(r)

sample_out = pd.read_csv(dataset_dir / "sample_output.csv")
sample_reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")

for _, row in sample_out.iterrows():
    cid = row["case_id"]
    steps = json.loads(row["steps_json"])
    gt_resources = list(dict.fromkeys(s["resource_id"] for s in steps))
    found = [rid for rid in gt_resources if rid in res_to_records]
    missing = [rid for rid in gt_resources if rid not in res_to_records]
    print(f"{cid}: {len(found)}/{len(gt_resources)} found in evidence extractors. Missing: {missing}")
