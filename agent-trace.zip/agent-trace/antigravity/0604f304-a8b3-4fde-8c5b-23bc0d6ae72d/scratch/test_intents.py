import sys
sys.path.insert(0, '.')
import pandas as pd
from pathlib import Path
from code.src.nlp.intent import IntentClassifier

for p in [Path("dataset"), Path("hackerrank-orchestrate-october26/dataset")]:
    if p.exists() and (p / "sample_output.csv").exists():
        dataset_dir = p
        break

reqs = pd.read_csv(dataset_dir / "sample_deletion_requests.csv")
out = pd.read_csv(dataset_dir / "sample_output.csv")
truth = dict(zip(out["case_id"], out["deletion_status"]))

mismatches = 0
for _, r in reqs.iterrows():
    cid = r["case_id"]
    txt = r["request_text"]
    pred_del = IntentClassifier.is_deletion_request(txt)
    is_na = (truth[cid] == "NOT_APPLICABLE")
    
    # Expected: if is_na -> pred_del is False; if not is_na -> pred_del is True
    if (is_na and pred_del) or (not is_na and not pred_del):
        mismatches += 1
        print(f"MISMATCH in {cid}: Truth={truth[cid]}, pred_is_del={pred_del}")
        print(f"  Text: {txt}\n")

print(f"Total intent mismatches: {mismatches} / {len(reqs)}")
